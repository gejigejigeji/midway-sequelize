import { EggPlugin } from 'midway';
export default {
  static: true, // default is true
} as EggPlugin;
