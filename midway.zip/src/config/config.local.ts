export const development = {
  watchDirs: [
    'app',
    'lib',
    'service',
    'interface',
    'utils',
    'config',
    'app.ts',
    'agent.ts',
    'interface.ts',
  ],
  overrideDefault: true,
};
