import {Sequelize} from 'sequelize-typescript';
import {User} from '../models/users/User';
import {Post} from '../models/posts/Post';
export const sequelize =  new Sequelize({
    database: 'test',
    dialect: 'mysql',
    username: 'root',
    password: '0',
    storage: ':memory:',
    // models: [`${__dirname}/lib/models`],
});
sequelize.addModels([Post, User]);