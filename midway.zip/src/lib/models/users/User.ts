import {Model, Table, Column, HasMany} from 'sequelize-typescript';
import {provide,inject} from 'midway'

import {Post} from '../posts/Post';

@provide()
@Table
export class User extends Model<User> {

  @Column
  name!: string;


  @HasMany(() => Post)
  posts: Post;

}
