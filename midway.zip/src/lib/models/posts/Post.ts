import {Model, Table, Column, ForeignKey, BelongsTo} from 'sequelize-typescript';
import {provide,inject} from 'midway'

import {User} from '../users/User';

@provide()
@Table
export class Post extends Model<Post> {

  @Column text!: string;
  @ForeignKey(() => User) @Column userId!: number;
  @BelongsTo(() => User) user: User;
}
